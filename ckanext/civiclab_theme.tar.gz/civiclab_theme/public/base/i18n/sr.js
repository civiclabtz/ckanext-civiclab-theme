{
  "": {
    "domain": "ckan", 
    "lang": "sr", 
    "plural-forms": "nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2);"
  }, 
  "Cancel": [
    null, 
    "Откажи"
  ], 
  "Edit": [
    null, 
    "Уређивање"
  ], 
  "Image": [
    null, 
    "Слика"
  ], 
  "Input is too short, must be at least one character": [
    "Input is too short, must be at least %(num)d characters", 
    "", 
    "", 
    ""
  ], 
  "Loading...": [
    null, 
    "Учитавање ..."
  ], 
  "URL": [
    null, 
    "URL"
  ], 
  "Upload": [
    null, 
    "Допреми"
  ], 
  "Upload a file": [
    null, 
    "Допреми фајл"
  ]
}