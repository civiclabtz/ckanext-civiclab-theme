{
  "": {
    "domain": "ckan", 
    "lang": "mk", 
    "plural-forms": "nplurals=2; plural=(n % 10 == 1 && n % 100 != 11) ? 0 : 1;"
  }, 
  "Add Filter": [
    null, 
    "Додади филтер"
  ], 
  "Confirm": [
    null, 
    "Потврди"
  ], 
  "Filters": [
    null, 
    "Филтри"
  ], 
  "Image": [
    null, 
    "Слика"
  ], 
  "Input is too short, must be at least one character": [
    "Input is too short, must be at least %(num)d characters", 
    "", 
    ""
  ], 
  "Loading...": [
    null, 
    "Се вчитува"
  ], 
  "Map": [
    null, 
    "Мапа"
  ], 
  "Remove": [
    null, 
    "Избриши"
  ], 
  "Show more": [
    null, 
    "Прикажи повеке"
  ]
}