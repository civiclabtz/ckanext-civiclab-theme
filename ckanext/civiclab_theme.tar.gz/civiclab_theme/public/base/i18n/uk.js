{
  "": {
    "domain": "ckan", 
    "lang": "uk", 
    "plural-forms": "nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2);"
  }, 
  "Filters": [
    null, 
    "Фільтри"
  ], 
  "Graph": [
    null, 
    "Графік"
  ], 
  "Image": [
    null, 
    "Зображення"
  ], 
  "Input is too short, must be at least one character": [
    "Input is too short, must be at least %(num)d characters", 
    "", 
    "", 
    ""
  ], 
  "Loading...": [
    null, 
    "Завантаження..."
  ], 
  "Map": [
    null, 
    "Карта"
  ]
}