{
  "": {
    "domain": "ckan", 
    "lang": "hu", 
    "plural-forms": "nplurals=2; plural=(n != 1);"
  }, 
  "Cancel": [
    null, 
    "Mégse"
  ], 
  "Edit": [
    null, 
    "Módosítás"
  ], 
  "Input is too short, must be at least one character": [
    "Input is too short, must be at least %(num)d characters", 
    "", 
    ""
  ], 
  "Loading...": [
    null, 
    "Betöltés ..."
  ], 
  "URL": [
    null, 
    "URL"
  ], 
  "Upload a file": [
    null, 
    "Fájl feltöltése"
  ]
}