{
  "": {
    "domain": "ckan", 
    "lang": "fa_IR", 
    "plural-forms": "nplurals=1; plural=0;"
  }, 
  "Input is too short, must be at least one character": [
    "Input is too short, must be at least %(num)d characters", 
    ""
  ], 
  "Map": [
    null, 
    "نقشه"
  ]
}