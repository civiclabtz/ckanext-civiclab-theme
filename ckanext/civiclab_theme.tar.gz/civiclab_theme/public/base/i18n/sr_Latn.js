{
  "": {
    "domain": "ckan", 
    "lang": "sr_Latn", 
    "plural-forms": "nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2);"
  }, 
  "Cancel": [
    null, 
    "Otkаži"
  ], 
  "Edit": [
    null, 
    "Uređivаnje"
  ], 
  "Image": [
    null, 
    "Slikа"
  ], 
  "Input is too short, must be at least one character": [
    "Input is too short, must be at least %(num)d characters", 
    "", 
    "", 
    ""
  ], 
  "Loading...": [
    null, 
    "Učitаvаnje ..."
  ], 
  "URL": [
    null, 
    "URL"
  ], 
  "Upload": [
    null, 
    "Dopremi"
  ], 
  "Upload a file": [
    null, 
    "Dopremi fаjl"
  ]
}