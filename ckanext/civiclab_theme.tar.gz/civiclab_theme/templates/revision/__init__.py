# encoding: utf-8

# empty file needed for pylons to find templates in this directory
