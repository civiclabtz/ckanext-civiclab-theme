"""Tests for plugin.py."""
import ckanext.civiclab_theme.plugin as plugin

def test_plugin():
    pass